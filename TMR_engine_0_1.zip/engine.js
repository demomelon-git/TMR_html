/* TMR Engine bootstrap: loads engine.json, game JSON and JS libraries. */
(async () => {
  "use strict";
  const status = document.getElementById("status");
  const title = document.getElementById("title");

  async function loadJSON(path) {
    const response = await fetch(path);
    if (!response.ok) throw new Error(`Не удалось загрузить ${path}: HTTP ${response.status}`);
    return response.json();
  }

  try {
    const config = await loadJSON("engine.json");
    const game = await loadJSON(config.game);
    const canvas = document.getElementById(config.canvas.element);
    if (!canvas) throw new Error(`Canvas #${config.canvas.element} не найден`);
    canvas.width = config.canvas.width || game.world.width;
    canvas.height = config.canvas.height || game.world.height;
    title.textContent = `${game.title || config.engine.name} — ${config.engine.version}`;

    // Библиотеки экспортируют свои API через window.TMRLibs.
    window.TMRLibs = window.TMRLibs || {};
    for (const path of config.libraries || []) {
      const response = await fetch(path);
      if (!response.ok) throw new Error(`Не удалось загрузить библиотеку ${path}`);
      const source = await response.text();
      // Код библиотек исполняется как обычный JavaScript после явной загрузки.
      // Загружайте только доверенные библиотеки проекта.
      const script = document.createElement("script");
      script.textContent = source + `\n//# sourceURL=${path}`;
      document.head.appendChild(script);
    }

    const renderer = window.TMRLibs.renderer;
    const physics = window.TMRLibs.physics;
    const audio = window.TMRLibs.audio;
    if (!renderer || !physics || !audio) throw new Error("Одна или несколько библиотек не зарегистрировались");

    const runtime = {
      config, game, canvas,
      ctx: canvas.getContext("2d"),
      keys: new Set(),
      player: { ...game.player },
      entities: (game.entities || []).map((e, id) => ({ id, ...e, active: true })),
      elapsed: 0,
      lastTime: 0,
      won: false,
      status
    };

    physics.init(runtime);
    renderer.init(runtime);
    audio.init(runtime);

    window.addEventListener("keydown", e => {
      runtime.keys.add(e.key.toLowerCase());
      if (["arrowup", "arrowdown", "arrowleft", "arrowright", " "].includes(e.key.toLowerCase())) e.preventDefault();
    });
    window.addEventListener("keyup", e => runtime.keys.delete(e.key.toLowerCase()));
    window.addEventListener("blur", () => runtime.keys.clear());

    status.textContent = "Движок запущен";
    function loop(timestamp) {
      const dt = Math.min((timestamp - (runtime.lastTime || timestamp)) / 1000, 0.05);
      runtime.lastTime = timestamp;
      runtime.elapsed += dt;
      physics.update(runtime, dt);
      renderer.render(runtime);
      requestAnimationFrame(loop);
    }
    requestAnimationFrame(loop);
    window.TMR = { config, game, runtime, libs: window.TMRLibs };
  } catch (err) {
    title.textContent = "Ошибка TMR";
    status.textContent = err.message;
    console.error(err);
  }
})();
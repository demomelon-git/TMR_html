/* TMR MP3 audio library. Browsers may require a user gesture before playback. */
(() => {
  window.TMRLibs = window.TMRLibs || {};
  window.TMRLibs.audio = {
    init(runtime) {
      const audioConfig = runtime.game.audio || {};
      if (!audioConfig.music) return;
      this.music = new Audio(audioConfig.music);
      this.music.loop = true;
      this.music.volume = Math.max(0,Math.min(1,audioConfig.volume ?? 0.5));
      const start = () => {
        this.music.play().catch(() => {});
        window.removeEventListener("pointerdown", start);
        window.removeEventListener("keydown", start);
      };
      window.addEventListener("pointerdown", start, { once: true });
      window.addEventListener("keydown", start, { once: true });
    },
    play(path, volume=1) {
      const sound = new Audio(path);
      sound.volume = Math.max(0,Math.min(1,volume));
      return sound.play();
    }
  };
})();
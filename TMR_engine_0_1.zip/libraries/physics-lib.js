/* TMR movement, bounds and simple collectible collision library */
(() => {
  window.TMRLibs = window.TMRLibs || {};
  window.TMRLibs.physics = {
    init(runtime) { runtime.won = false; },
    update(r, dt) {
      if (r.won) return;
      const p = r.player, keys = r.keys;
      let dx=0, dy=0;
      if (keys.has("arrowleft") || keys.has("a")) dx--;
      if (keys.has("arrowright") || keys.has("d")) dx++;
      if (keys.has("arrowup") || keys.has("w")) dy--;
      if (keys.has("arrowdown") || keys.has("s")) dy++;
      if (dx && dy) { dx *= Math.SQRT1_2; dy *= Math.SQRT1_2; }
      const oldX=p.x, oldY=p.y;
      p.x += dx*(p.speed||200)*dt;
      p.y += dy*(p.speed||200)*dt;
      p.x = Math.max(p.radius,Math.min(r.canvas.width-p.radius,p.x));
      p.y = Math.max(p.radius,Math.min(r.canvas.height-p.radius,p.y));

      // Simple AABB wall collision: revert movement if player overlaps a wall.
      for (const e of r.entities) {
        if (e.type !== "wall") continue;
        const nearestX = Math.max(e.x, Math.min(p.x, e.x+e.width));
        const nearestY = Math.max(e.y, Math.min(p.y, e.y+e.height));
        if (Math.hypot(p.x-nearestX,p.y-nearestY) < p.radius) { p.x=oldX; p.y=oldY; break; }
      }
      for (const e of r.entities) {
        if (!e.active || e.type !== "collectible") continue;
        if (Math.hypot(p.x-e.x,p.y-e.y) < p.radius+(e.radius||12)) e.active=false;
      }
      if (r.entities.filter(e=>e.type==="collectible"&&e.active).length===0) r.won=true;
    }
  };
})();
/* TMR renderer library */
(() => {
  window.TMRLibs = window.TMRLibs || {};
  window.TMRLibs.renderer = {
    init(runtime) {
      this.images = new Map();
      const textures = new Set();
      if (runtime.game.player.texture) textures.add(runtime.game.player.texture);
      for (const entity of runtime.game.entities || []) if (entity.texture) textures.add(entity.texture);
      for (const path of textures) {
        const image = new Image();
        image.src = path;
        this.images.set(path, image);
      }
    },
    render(r) {
      const ctx = r.ctx, canvas = r.canvas, world = r.game.world;
      ctx.fillStyle = world.background || "#172033";
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.strokeStyle = "rgba(190,205,240,.07)";
      for (let x=0; x<canvas.width; x+=40) { ctx.beginPath(); ctx.moveTo(x,0); ctx.lineTo(x,canvas.height); ctx.stroke(); }
      for (let y=0; y<canvas.height; y+=40) { ctx.beginPath(); ctx.moveTo(0,y); ctx.lineTo(canvas.width,y); ctx.stroke(); }

      for (const e of r.entities) {
        if (!e.active) continue;
        if (e.type === "wall") {
          ctx.fillStyle = e.color || "#46536d";
          ctx.fillRect(e.x, e.y, e.width, e.height);
        } else if (e.type === "collectible") {
          const rad = e.radius || 12;
          ctx.save(); ctx.translate(e.x,e.y); ctx.rotate(r.elapsed*1.5);
          ctx.fillStyle = e.color || "#fbbf24";
          ctx.beginPath(); ctx.moveTo(0,-rad); ctx.lineTo(rad*.7,0); ctx.lineTo(0,rad); ctx.lineTo(-rad*.7,0); ctx.closePath(); ctx.fill();
          ctx.restore();
        } else if (e.type === "sprite" && e.texture) {
          const img = this.images.get(e.texture);
          if (img && img.complete && img.naturalWidth) ctx.drawImage(img,e.x,e.y,e.width||32,e.height||32);
        }
      }

      const p = r.player;
      const img = p.texture && this.images.get(p.texture);
      if (img && img.complete && img.naturalWidth) ctx.drawImage(img,p.x-p.radius,p.y-p.radius,p.radius*2,p.radius*2);
      else {
        ctx.fillStyle = p.color || "#60a5fa";
        ctx.beginPath(); ctx.arc(p.x,p.y,p.radius,0,Math.PI*2); ctx.fill();
        ctx.strokeStyle = "#e0f2fe"; ctx.lineWidth = 3; ctx.stroke();
      }

      const total = r.entities.filter(e=>e.type==="collectible").length;
      const got = r.entities.filter(e=>e.type==="collectible"&&!e.active).length;
      if (r.won) {
        ctx.fillStyle="rgba(8,15,30,.76)"; ctx.fillRect(0,0,canvas.width,canvas.height);
        ctx.textAlign="center"; ctx.fillStyle="#f8fafc"; ctx.font="bold 46px system-ui";
        ctx.fillText("ПОБЕДА!",canvas.width/2,canvas.height/2);
        ctx.font="20px system-ui"; ctx.fillStyle="#fbbf24";
        ctx.fillText("Ты собрал все кристаллы",canvas.width/2,canvas.height/2+42);
      }
      r.status.textContent = r.won ? "Победа!" : `Кристаллы: ${got}/${total}`;
    }
  };
})();
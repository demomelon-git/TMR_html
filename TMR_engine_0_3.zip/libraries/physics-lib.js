/* TMR physics: движение, скольжение по стенам, платформер (world.gravity > 0), сбор, опасности, цель, жизни. */
(() => {
  window.TMRLibs = window.TMRLibs || {};
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const solid = e => e.active && (e.type === "wall" || e.solid) && e.width > 0 && e.height > 0;

  // Выталкивает круг p из прямоугольника e. Возвращает нормаль выталкивания или null.
  function circleRect(p, e) {
    const nx = clamp(p.x, e.x, e.x + e.width), ny = clamp(p.y, e.y, e.y + e.height);
    const dx = p.x - nx, dy = p.y - ny, d = Math.hypot(dx, dy);
    if (d >= p.radius) return null;
    if (d === 0) { // центр внутри прямоугольника: выходим по ближайшей грани
      const l = p.x - e.x, rt = e.x + e.width - p.x, t = p.y - e.y, b = e.y + e.height - p.y, m = Math.min(l, rt, t, b);
      if (m === l) { p.x = e.x - p.radius; return { x: -1, y: 0 }; }
      if (m === rt) { p.x = e.x + e.width + p.radius; return { x: 1, y: 0 }; }
      if (m === t) { p.y = e.y - p.radius; return { x: 0, y: -1 }; }
      p.y = e.y + e.height + p.radius; return { x: 0, y: 1 };
    }
    const push = p.radius - d;
    p.x += dx / d * push; p.y += dy / d * push;
    return { x: dx / d, y: dy / d };
  }
  // Касание круга игрока с кругом (radius) или прямоугольником (width/height).
  function touches(p, e) {
    if (e.width > 0 && e.height > 0) {
      const nx = clamp(p.x, e.x, e.x + e.width), ny = clamp(p.y, e.y, e.y + e.height);
      return Math.hypot(p.x - nx, p.y - ny) < p.radius;
    }
    return Math.hypot(p.x - e.x, p.y - e.y) < p.radius + (e.radius || 12);
  }

  const lib = {
    circleRect, touches,
    init(r) { r.on("reset", () => this.spawn(r)); },
    spawn(r) {
      const p = r.player;
      p.x = p.spawn.x; p.y = p.spawn.y; p.vx = p.vy = 0; p.px = p.x; p.py = p.y;
      p.grounded = false; p.invuln = 0;
      for (const e of r.entities) if (e.move) { e.ox = e.x; e.oy = e.y; }
    },
    hurt(r, source) {
      const p = r.player;
      if (p.invuln > 0) return;
      r.lives--; p.invuln = p.invulnTime ?? 1.5;
      r.emit("hit", source);
      if (r.lives <= 0) { r.lives = 0; r.setState("lost"); return; }
      p.x = p.spawn.x; p.y = p.spawn.y; p.vx = p.vy = 0; p.px = p.x; p.py = p.y;
    },
    update(r, dt) {
      const p = r.player, w = r.world, g = w.gravity || 0;
      p.px = p.x; p.py = p.y;
      p.invuln = Math.max(0, (p.invuln || 0) - dt);

      // Движущиеся объекты: move = { axis: "x"|"y", range: px, speed: px/с, phase }
      for (const e of r.entities) {
        if (!e.active || !e.move) continue;
        const m = e.move, range = m.range || 0;
        if (!range) continue;
        const s = Math.sin(r.elapsed * (m.speed || 60) / range + (m.phase || 0)) * range;
        if (m.axis === "y") e.y = e.oy + s; else e.x = e.ox + s;
      }

      const a = r.axis(), speed = p.speed || 200;
      p.vx = a.x * speed;
      if (g > 0) {
        p.vy = Math.min((p.vy || 0) + g * dt, 1400);
        const jump = r.keys.has("space") || r.keys.has("w") || r.keys.has("arrowup") || a.y < -0.6;
        if (jump && p.grounded) { p.vy = -(p.jump || 520); r.emit("jump"); }
      } else p.vy = a.y * speed;

      p.grounded = false;
      const dist = Math.hypot(p.vx, p.vy) * dt;
      const n = Math.max(1, Math.ceil(dist / (p.radius * 0.5))); // подшаги: без «пролёта» сквозь тонкие стены
      for (let i = 0; i < n; i++) {
        p.x += p.vx * dt / n; p.y += p.vy * dt / n;
        for (const e of r.entities) {
          if (!solid(e)) continue;
          const nrm = circleRect(p, e);
          if (!nrm) continue;
          if (g > 0) {
            if (nrm.y < -0.5) { p.grounded = true; if (p.vy > 0) p.vy = 0; }
            else if (nrm.y > 0.5 && p.vy < 0) p.vy = 0;
          }
        }
        p.x = clamp(p.x, p.radius, w.width - p.radius);
        p.y = clamp(p.y, p.radius, w.height - p.radius);
        if (g > 0 && p.y >= w.height - p.radius) { p.grounded = true; if (p.vy > 0) p.vy = 0; }
      }

      const hasGoal = r.entities.some(e => e.type === "goal");
      for (const e of r.entities) {
        if (!e.active) continue;
        if (e.type === "collectible") {
          if (touches(p, e)) { e.active = false; r.score += e.value ?? 1; r.emit("collect", e); }
        } else if (e.type === "hazard") {
          if (touches(p, e)) this.hurt(r, e);
        } else if (e.type === "goal") {
          if (touches(p, e) && (!e.requires || r.count("collectible") === 0)) r.setState("won");
        }
        if (r.state !== "playing") return;
      }
      // Победа: все кристаллы собраны (если на уровне нет отдельной цели). Без кристаллов победы нет.
      if (!hasGoal && r.entities.some(e => e.type === "collectible") && r.count("collectible") === 0) r.setState("won");
    }
  };
  window.TMRLibs.physics = lib;
})();

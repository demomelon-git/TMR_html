/* TMR input: мышь, касания, геймпад. Клавиатура — в ядре.
   2D: палец = виртуальный стик. 3D: левая половина экрана — движение, правая — обзор, круг справа внизу — прыжок;
   мышь — захват курсора (клик по полю), геймпад — левый стик ходьба, правый — обзор, A — прыжок. */
(() => {
  window.TMRLibs = window.TMRLibs || {};
  const STICK_RADIUS = 60, DEAD = 0.18, TOUCH_LOOK = 0.006, MOUSE_LOOK = 0.0022;
  window.TMRLibs.input = {
    init(r) {
      const is3d = r.mode === "3d";
      const input = r.input = {
        axis: { x: 0, y: 0 },          // стик / геймпад (клавиатура — через r.keys)
        look: { dx: 0, dy: 0 },        // накопленный поворот в радианах (3D)
        lookAxis: { x: 0, y: 0 },      // правый стик геймпада (3D)
        jump: false, touch: false,
        pointer: { x: 0, y: 0, worldX: 0, worldY: 0, down: false, pressed: false, released: false, type: "mouse" },
        stick: { active: false, ox: 0, oy: 0, x: 0, y: 0 },
        gamepad: false
      };
      const ids = this._ids = { stick: null, look: null, jump: null };
      let last = { x: 0, y: 0 };
      const c = r.canvas;
      c.style.touchAction = "none";
      const pos = e => {
        const b = c.getBoundingClientRect();
        return { x: (e.clientX - b.left) * r.view.width / b.width, y: (e.clientY - b.top) * r.view.height / b.height };
      };
      const upd = e => {
        const p = pos(e), ptr = input.pointer;
        ptr.x = p.x; ptr.y = p.y; ptr.type = e.pointerType;
        if (!is3d) { const w = r.screenToWorld(p.x, p.y); ptr.worldX = w.x; ptr.worldY = w.y; }
        return p;
      };
      const setStick = (p) => {
        const s = input.stick;
        let dx = (p.x - s.ox) / STICK_RADIUS, dy = (p.y - s.oy) / STICK_RADIUS;
        const len = Math.hypot(dx, dy);
        if (len > 1) { dx /= len; dy /= len; }
        s.x = dx; s.y = dy;
      };
      c.addEventListener("pointerdown", e => {
        const p = upd(e); input.pointer.down = true; input.pointer.pressed = true;
        if (e.pointerType === "mouse") {
          if (is3d && c.requestPointerLock && !document.pointerLockElement) c.requestPointerLock();
          return;
        }
        input.touch = true; c.setPointerCapture(e.pointerId);
        if (!is3d) { Object.assign(input.stick, { active: true, ox: p.x, oy: p.y, x: 0, y: 0 }); return; }
        if (Math.hypot(p.x - (r.view.width - 80), p.y - (r.view.height - 80)) < 55) ids.jump = e.pointerId;
        else if (p.x < r.view.width / 2) { if (ids.stick === null) { ids.stick = e.pointerId; Object.assign(input.stick, { active: true, ox: p.x, oy: p.y, x: 0, y: 0 }); } }
        else if (ids.look === null) { ids.look = e.pointerId; last = p; }
      });
      c.addEventListener("pointermove", e => {
        const p = upd(e);
        if (e.pointerType === "mouse") return;
        if (!is3d) { if (input.stick.active) setStick(p); return; }
        if (e.pointerId === ids.stick) setStick(p);
        else if (e.pointerId === ids.look) { input.look.dx += (p.x - last.x) * TOUCH_LOOK; input.look.dy += (p.y - last.y) * TOUCH_LOOK; last = p; }
      });
      const up = e => {
        upd(e); input.pointer.down = false; input.pointer.released = true;
        if (!is3d) { Object.assign(input.stick, { active: false, x: 0, y: 0 }); return; }
        if (e.pointerId === ids.stick) { ids.stick = null; Object.assign(input.stick, { active: false, x: 0, y: 0 }); }
        if (e.pointerId === ids.look) ids.look = null;
        if (e.pointerId === ids.jump) ids.jump = null;
      };
      c.addEventListener("pointerup", up);
      c.addEventListener("pointercancel", up);

      if (is3d) { // мышь: обзор при захваченном курсоре; Esc/выход из захвата = пауза
        document.addEventListener("mousemove", e => {
          if (document.pointerLockElement !== c) return;
          input.look.dx += e.movementX * MOUSE_LOOK; input.look.dy += e.movementY * MOUSE_LOOK;
        });
        document.addEventListener("pointerlockchange", () => { if (!document.pointerLockElement) r.pause(); });
      }
      this._btn = {};
    },
    tick(r) {
      const input = r.input, ids = this._ids;
      let x = 0, y = 0, lx = 0, ly = 0, padJump = false;
      if (input.stick.active && Math.hypot(input.stick.x, input.stick.y) > DEAD) { x = input.stick.x; y = input.stick.y; }
      const pad = (navigator.getGamepads ? [...navigator.getGamepads()] : []).find(Boolean);
      input.gamepad = !!pad;
      if (pad) {
        const ax = pad.axes[0] || 0, ay = pad.axes[1] || 0;
        if (Math.hypot(ax, ay) > 0.2) { x += ax; y += ay; }
        const b = i => !!(pad.buttons[i] && pad.buttons[i].pressed);
        if (r.mode === "3d") {
          const rx = pad.axes[2] || 0, ry = pad.axes[3] || 0;
          if (Math.hypot(rx, ry) > 0.2) { lx = rx; ly = ry; }
          padJump = b(0);
        } else { x += (b(15) ? 1 : 0) - (b(14) ? 1 : 0); y += (b(13) ? 1 : 0) - (b(12) ? 1 : 0); }
        const edge = (i, fn) => { const now = b(i); if (now && !this._btn[i]) fn(); this._btn[i] = now; };
        edge(9, () => r.togglePause());
        edge(0, () => { if (r.state === "won" || r.state === "lost") r.restart(); });
      }
      input.axis.x = Math.max(-1, Math.min(1, x));
      input.axis.y = Math.max(-1, Math.min(1, y));
      input.lookAxis.x = lx; input.lookAxis.y = ly;
      input.jump = ids.jump !== null || padJump;
    },
    endFrame(r) { r.input.pointer.pressed = false; r.input.pointer.released = false; }
  };
})();

/* TMR audio: музыка (MP3), эффекты (MP3 или встроенный синтезатор), громкость, M — выключить звук. */
(() => {
  window.TMRLibs = window.TMRLibs || {};
  const PRESETS = {
    collect: { freq: 660, to: 990, dur: 0.12, type: "triangle" },
    hit: { freq: 220, to: 60, dur: 0.3, type: "sawtooth", vol: 0.25 },
    jump: { freq: 300, to: 620, dur: 0.12, type: "square", vol: 0.12 },
    win: { notes: [523, 659, 784, 1047], dur: 0.14, type: "triangle" },
    lose: { notes: [392, 330, 262, 196], dur: 0.18, type: "sawtooth", vol: 0.15 }
  };
  const clamp01 = v => Math.max(0, Math.min(1, v));

  window.TMRLibs.audio = {
    muted: false, master: 1, music: null, ac: null, files: {},
    init(r) {
      this.r = r;
      const cfg = this.cfg = r.game.audio || {};
      this.master = clamp01(cfg.master ?? 1);
      for (const [name, v] of Object.entries(cfg.sfx || {})) {
        if (typeof v !== "string") continue;
        const a = new Audio(); a.preload = "auto"; a.src = v;
        const rec = this.files[name] = { a, ok: true };
        a.addEventListener("error", () => { rec.ok = false; });
      }
      if (cfg.music) {
        this.music = new Audio(cfg.music); this.music.loop = true;
        this.music.addEventListener("error", () => { this.music = null; });
      }
      const unlock = () => {
        this.muted = !!(r.save && r.save.get("audio.muted", false));
        this.ensure(); this.applyMusic();
        window.removeEventListener("pointerdown", unlock); window.removeEventListener("keydown", unlock);
      };
      window.addEventListener("pointerdown", unlock); window.addEventListener("keydown", unlock);
      for (const name of ["collect", "hit", "win", "lose", "jump"]) r.on(name, () => this.sfx(name));
      r.on("keydown", k => { if (k === "m") this.toggleMute(); });
      r.on("state", s => { if (!this.music) return; if (s === "paused") this.music.pause(); else if (s === "playing" || s === "won" || s === "lost") this.applyMusic(); });
    },
    ensure() {
      if (!this.ac) { const AC = window.AudioContext || window.webkitAudioContext; if (AC) this.ac = new AC(); }
      if (this.ac && this.ac.state === "suspended") this.ac.resume().catch(() => {});
      return this.ac;
    },
    applyMusic() {
      const m = this.music; if (!m) return;
      m.volume = clamp01((this.cfg.volume ?? 0.5) * this.master); m.muted = this.muted;
      m.play().catch(() => {});
    },
    setVolume(v) { this.master = clamp01(v); this.applyMusic(); },
    toggleMute() {
      this.muted = !this.muted;
      if (this.music) this.music.muted = this.muted;
      if (this.r.save) this.r.save.set("audio.muted", this.muted);
      this.r.emit("audio:mute", this.muted);
      return this.muted;
    },
    sfx(name) {
      if (this.muted) return;
      const v = (this.cfg.sfx || {})[name], vol = (this.cfg.sfxVolume ?? 1) * this.master;
      if (typeof v === "string") {
        const f = this.files[name];
        if (f && f.ok) { const a = f.a.cloneNode(); a.volume = clamp01(vol); a.play().catch(() => {}); return; }
        if (this.cfg.defaults !== false && PRESETS[name]) this.synth(PRESETS[name], vol);
      } else if (v && typeof v === "object") this.synth(v, vol);
      else if (this.cfg.defaults !== false && PRESETS[name]) this.synth(PRESETS[name], vol);
    },
    // Простой синтезатор: { freq, to, dur, type, vol } или { notes: [Гц...], dur, type, vol }
    synth(o, vol = 1) {
      const ac = this.ac; if (!ac || ac.state !== "running") return;
      const notes = o.notes || [o.freq || 440], dur = o.dur || 0.15, t0 = ac.currentTime;
      notes.forEach((f, i) => {
        const osc = ac.createOscillator(), gain = ac.createGain(), t = t0 + i * dur;
        osc.type = o.type || "square"; osc.frequency.setValueAtTime(f, t);
        if (o.to && !o.notes) osc.frequency.exponentialRampToValueAtTime(Math.max(1, o.to), t + dur);
        gain.gain.setValueAtTime((o.vol ?? 0.2) * vol, t);
        gain.gain.exponentialRampToValueAtTime(0.0001, t + dur);
        osc.connect(gain).connect(ac.destination); osc.start(t); osc.stop(t + dur + 0.02);
      });
    },
    // Совместимость с 0.1
    play(path, volume = 1) { const a = new Audio(path); a.volume = clamp01(volume * this.master); a.muted = this.muted; return a.play(); }
  };
})();

/* TMR physics3d: игрок-капсула (AABB), гравитация, прыжок, коллизии с коробками по осям, движущиеся платформы,
   сбор, опасности, цель, жизни. Оси: x,z — пол, y — вверх; y игрока — уровень ног. Сущности: x,y,z — ЦЕНТР. */
(() => {
  window.TMRLibs = window.TMRLibs || {};
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const isBox = e => e.width > 0 && e.height > 0 && e.depth > 0;
  const bounds = e => ({ e, x0: e.x - e.width / 2, x1: e.x + e.width / 2, y0: e.y - e.height / 2, y1: e.y + e.height / 2, z0: e.z - e.depth / 2, z1: e.z + e.depth / 2 });

  const lib = {
    init(r) { r.on("reset", () => this.spawn(r)); },
    spawn(r) {
      const p = r.player, s = p.spawn;
      p.x = s.x; p.y = s.y; p.z = s.z; p.yaw = s.yaw || 0; p.pitch = 0;
      p.vx = p.vy = p.vz = 0; p.px = p.x; p.py = p.y; p.pz = p.z; p.grounded = false; p.coyote = 0; p.invuln = 0;
      for (const e of r.entities) if (e.move) { e.ox = e.x; e.oy = e.y; e.oz = e.z; }
    },
    hurt(r, source) {
      const p = r.player;
      if (p.invuln > 0) return;
      r.lives--; p.invuln = p.invulnTime ?? 1.5;
      r.emit("hit", source);
      if (r.lives <= 0) { r.lives = 0; r.setState("lost"); return; }
      const s = p.spawn; p.x = s.x; p.y = s.y; p.z = s.z; p.vx = p.vy = p.vz = 0; p.px = p.x; p.py = p.y; p.pz = p.z;
    },
    // Обзор применяется каждый кадр (а не раз в шаг физики) — управление без задержки
    tick(r, dt) {
      const p = r.player, inp = r.input;
      if (r.state !== "playing") { if (inp) inp.look.dx = inp.look.dy = 0; return; }
      const k = r.keys, sens = p.sensitivity || 1;
      if (inp) {
        p.yaw -= inp.look.dx * sens; p.pitch -= inp.look.dy * sens;
        inp.look.dx = inp.look.dy = 0;
        p.yaw -= inp.lookAxis.x * 2.6 * dt * sens; p.pitch -= inp.lookAxis.y * 2.0 * dt * sens;
      }
      p.yaw += ((k.has("arrowleft") ? 1 : 0) - (k.has("arrowright") ? 1 : 0)) * 2.2 * dt * sens;
      p.pitch += ((k.has("arrowup") ? 1 : 0) - (k.has("arrowdown") ? 1 : 0)) * 1.6 * dt * sens;
      p.pitch = clamp(p.pitch, -1.45, 1.45);
    },
    update(r, dt) {
      const p = r.player, w = r.world, g = w.gravity ?? 24, rad = p.radius, H = p.height;
      p.px = p.x; p.py = p.y; p.pz = p.z;
      p.invuln = Math.max(0, (p.invuln || 0) - dt);

      // Движущиеся объекты: move = { axis: "x"|"y"|"z", range, speed, phase }. Игрок едет на платформах.
      for (const e of r.entities) {
        if (!e.active || !e.move || !e.move.range) continue;
        const m = e.move, ax = m.axis || "x";
        const px = e.x, py = e.y, pz = e.z;
        const s = Math.sin(r.elapsed * (m.speed || 2) / m.range + (m.phase || 0)) * m.range;
        e[ax] = e["o" + ax] + s;
        if (isBox(e) && p.grounded && Math.abs(p.y - (py + e.height / 2)) < 0.08 &&
            p.x + rad > px - e.width / 2 && p.x - rad < px + e.width / 2 && p.z + rad > pz - e.depth / 2 && p.z - rad < pz + e.depth / 2) {
          p.x += e.x - px; p.y += e.y - py; p.z += e.z - pz;
        }
      }
      const solids = [];
      for (const e of r.entities) if (e.active && (e.type === "wall" || e.solid) && isBox(e)) solids.push(bounds(e));
      const hit = b => p.x + rad > b.x0 && p.x - rad < b.x1 && p.y + H > b.y0 && p.y < b.y1 && p.z + rad > b.z0 && p.z - rad < b.z1;

      // Ввод: вперёд/назад/вбок относительно взгляда
      const k = r.keys, st = r.input ? r.input.axis : { x: 0, y: 0 };
      let fwd = (k.has("w") ? 1 : 0) - (k.has("s") ? 1 : 0) - st.y, str = (k.has("d") ? 1 : 0) - (k.has("a") ? 1 : 0) + st.x;
      fwd = clamp(fwd, -1, 1); str = clamp(str, -1, 1);
      const len = Math.hypot(fwd, str); if (len > 1) { fwd /= len; str /= len; }
      const speed = (p.speed || 6) * (k.has("shift") ? 1.6 : 1), sy = Math.sin(p.yaw), cy = Math.cos(p.yaw);
      p.vx = (-sy * fwd + cy * str) * speed; p.vz = (-cy * fwd - sy * str) * speed;
      p.vy = Math.max((p.vy || 0) - g * dt, -55);
      p.coyote = p.grounded ? 0.08 : Math.max(0, (p.coyote || 0) - dt);
      const wantJump = k.has("space") || (r.input && r.input.jump);
      if (wantJump && (p.grounded || p.coyote > 0)) { p.vy = p.jump || 8; p.grounded = false; p.coyote = 0; r.emit("jump"); }

      const dx = p.vx * dt, dy = p.vy * dt, dz = p.vz * dt;
      const n = Math.max(1, Math.ceil(Math.max(Math.abs(dx), Math.abs(dy), Math.abs(dz)) / (rad * 0.8))); // подшаги
      p.grounded = false;
      const bounded = w.bounded ?? (w.ground !== false);
      for (let i = 0; i < n; i++) {
        p.x += dx / n;
        if (dx) for (const b of solids) if (hit(b)) p.x = dx > 0 ? b.x0 - rad : b.x1 + rad;
        p.z += dz / n;
        if (dz) for (const b of solids) if (hit(b)) p.z = dz > 0 ? b.z0 - rad : b.z1 + rad;
        p.y += dy / n;
        if (dy) for (const b of solids) if (hit(b)) {
          if (dy > 0) { p.y = b.y0 - H; if (p.vy > 0) p.vy = 0; }
          else { p.y = b.y1; p.grounded = true; if (p.vy < 0) p.vy = 0; }
        }
        if (w.ground !== false && p.y < 0) { p.y = 0; p.grounded = true; if (p.vy < 0) p.vy = 0; }
        if (bounded) { p.x = clamp(p.x, -w.width / 2 + rad, w.width / 2 - rad); p.z = clamp(p.z, -w.depth / 2 + rad, w.depth / 2 - rad); }
      }
      // Если движущаяся стена зажала игрока — выталкиваем по наименьшему проникновению
      for (const b of solids) if (hit(b)) {
        const o = [[p.x + rad - b.x0, "x", -1], [b.x1 - (p.x - rad), "x", 1], [p.z + rad - b.z0, "z", -1], [b.z1 - (p.z - rad), "z", 1], [p.y + H - b.y0, "y", -1], [b.y1 - p.y, "y", 1]].sort((a, c) => a[0] - c[0])[0];
        p[o[1]] += o[0] * o[2]; if (o[1] === "y" && o[2] > 0) p.grounded = true;
      }
      if (p.y < (w.killY ?? -25)) { this.hurt(r, null); if (r.state !== "playing") return; }

      // Взаимодействия: капсула игрока против сфер, коробок и цилиндра цели
      const y0 = p.y + rad, y1 = p.y + H - rad, hasGoal = r.entities.some(e => e.type === "goal");
      const touches = e => {
        const cy = clamp(e.y, y0, y1);
        if (e.type === "goal" && !isBox(e)) { // вертикальный цилиндр
          const h = e.height || 3;
          return Math.hypot(p.x - e.x, p.z - e.z) < rad + (e.radius || 1) && p.y < e.y + h / 2 && p.y + H > e.y - h / 2;
        }
        if (isBox(e)) {
          const qx = clamp(p.x, e.x - e.width / 2, e.x + e.width / 2), qy = clamp(cy, e.y - e.height / 2, e.y + e.height / 2), qz = clamp(p.z, e.z - e.depth / 2, e.z + e.depth / 2);
          return Math.hypot(p.x - qx, cy - qy, p.z - qz) < rad;
        }
        return Math.hypot(p.x - e.x, cy - e.y, p.z - e.z) < rad + (e.radius || 0.4);
      };
      for (const e of r.entities) {
        if (!e.active) continue;
        if (e.type === "collectible") { if (touches(e)) { e.active = false; r.score += e.value ?? 1; r.emit("collect", e); } }
        else if (e.type === "hazard") { if (touches(e)) this.hurt(r, e); }
        else if (e.type === "goal") { if (touches(e) && (!e.requires || r.count("collectible") === 0)) r.setState("won"); }
        if (r.state !== "playing") return;
      }
      if (!hasGoal && r.entities.some(e => e.type === "collectible") && r.count("collectible") === 0) r.setState("won");
    }
  };
  window.TMRLibs.physics3d = lib;
})();

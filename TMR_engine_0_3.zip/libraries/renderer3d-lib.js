/* TMR renderer3d: WebGL без зависимостей — коробки, сферы, цилиндры, свет, туман, сетка на поверхностях,
   камера от 1-го/3-го лица (V), частицы, всплывающие тексты. HUD рисует renderer-lib на слое #tmr-hud. */
(() => {
  window.TMRLibs = window.TMRLibs || {};

  const VS = `
attribute vec3 a_pos; attribute vec3 a_nrm;
uniform mat4 u_mvp; uniform mat4 u_model; uniform vec2 u_rot;
varying vec3 v_n; varying vec3 v_w;
void main(){
  v_w = (u_model * vec4(a_pos, 1.0)).xyz;
  v_n = vec3(u_rot.x*a_nrm.x + u_rot.y*a_nrm.z, a_nrm.y, -u_rot.y*a_nrm.x + u_rot.x*a_nrm.z);
  gl_Position = u_mvp * vec4(a_pos, 1.0);
}`;
  const FS = `
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif
varying vec3 v_n; varying vec3 v_w;
uniform vec3 u_color; uniform vec3 u_sun; uniform vec3 u_fogc; uniform vec3 u_eye;
uniform float u_emit; uniform float u_grid; uniform float u_fogd; uniform float u_amb;
void main(){
  vec3 n = normalize(v_n);
  float diff = max(dot(n, normalize(u_sun)), 0.0);
  float hemi = 0.6 + 0.4 * n.y;
  vec3 c = u_color * (u_amb * hemi + (1.0 - u_amb) * diff);
  float dist = length(v_w - u_eye);
  float fog = clamp(1.0 - exp(-pow(dist * u_fogd, 2.0)), 0.0, 1.0);
  if (u_grid > 0.0) {
    vec3 an = abs(n);
    vec3 f = abs(fract(v_w / u_grid - 0.5) - 0.5) * u_grid;
    float l = an.y > 0.5 ? min(f.x, f.z) : (an.x > 0.5 ? min(f.y, f.z) : min(f.x, f.y));
    c = mix(c, c * 0.62, (1.0 - smoothstep(0.0, 0.04, l)) * (1.0 - fog));
  }
  c += u_color * u_emit;
  gl_FragColor = vec4(mix(c, u_fogc, fog), 1.0);
}`;

  // ---------- Математика (матрицы column-major) ----------
  const mul = (a, b) => { const o = new Float32Array(16); for (let c = 0; c < 4; c++) for (let r = 0; r < 4; r++) { let s = 0; for (let k = 0; k < 4; k++) s += a[k * 4 + r] * b[c * 4 + k]; o[c * 4 + r] = s; } return o; };
  const persp = (fov, asp, n, f) => { const t = 1 / Math.tan(fov / 2); return new Float32Array([t / asp, 0, 0, 0, 0, t, 0, 0, 0, 0, (f + n) / (n - f), -1, 0, 0, 2 * f * n / (n - f), 0]); };
  const lookAt = (e, c) => {
    let zx = e[0] - c[0], zy = e[1] - c[1], zz = e[2] - c[2], l = Math.hypot(zx, zy, zz) || 1; zx /= l; zy /= l; zz /= l;
    let xx = zz, xy = 0, xz = -zx; l = Math.hypot(xx, xy, xz) || 1; xx /= l; xz /= l; // up = (0,1,0)
    const yx = zy * xz - zz * xy, yy = zz * xx - zx * xz, yz = zx * xy - zy * xx;
    return new Float32Array([xx, yx, zx, 0, xy, yy, zy, 0, xz, yz, zz, 0, -(xx * e[0] + xy * e[1] + xz * e[2]), -(yx * e[0] + yy * e[1] + yz * e[2]), -(zx * e[0] + zy * e[1] + zz * e[2]), 1]);
  };
  const model = (x, y, z, sx, sy, sz, rot) => { const c = Math.cos(rot || 0), s = Math.sin(rot || 0); return new Float32Array([c * sx, 0, -s * sx, 0, 0, sy, 0, 0, s * sz, 0, c * sz, 0, x, y, z, 1]); };

  const colCache = new Map();
  const col = (h, d) => {
    if (!h) return d || [1, 1, 1];
    let c = colCache.get(h);
    if (!c) {
      let s = String(h).replace("#", ""); if (s.length === 3) s = s.split("").map(x => x + x).join("");
      const n = parseInt(s, 16);
      c = s.length !== 6 || Number.isNaN(n) ? (d || [1, 1, 1]) : [(n >> 16 & 255) / 255, (n >> 8 & 255) / 255, (n & 255) / 255];
      colCache.set(h, c);
    }
    return c;
  };

  // ---------- Геометрия: interleaved [pos, normal], единичные размеры ----------
  const V = (a, p, n) => a.push(p[0], p[1], p[2], n[0], n[1], n[2]);
  function cubeData() {
    const a = [];
    for (const n of [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]]) {
      const u = n[0] ? [0, 1, 0] : [1, 0, 0], v = [n[1] * u[2] - n[2] * u[1], n[2] * u[0] - n[0] * u[2], n[0] * u[1] - n[1] * u[0]];
      const P = (s, t) => [0.5 * (n[0] + s * u[0] + t * v[0]), 0.5 * (n[1] + s * u[1] + t * v[1]), 0.5 * (n[2] + s * u[2] + t * v[2])];
      for (const [s, t] of [[-1, -1], [1, -1], [1, 1], [-1, -1], [1, 1], [-1, 1]]) V(a, P(s, t), n);
    }
    return a;
  }
  function sphereData(lat = 12, lon = 18) {
    const a = [], pt = (i, j) => { const th = i / lat * Math.PI, ph = j / lon * Math.PI * 2, n = [Math.sin(th) * Math.cos(ph), Math.cos(th), Math.sin(th) * Math.sin(ph)]; return [[n[0] * 0.5, n[1] * 0.5, n[2] * 0.5], n]; };
    for (let i = 0; i < lat; i++) for (let j = 0; j < lon; j++) {
      const A = pt(i, j), B = pt(i + 1, j), C = pt(i + 1, j + 1), D = pt(i, j + 1);
      for (const q of [A, B, C, A, C, D]) V(a, q[0], q[1]);
    }
    return a;
  }
  function cylinderData(seg = 18) {
    const a = [];
    for (let i = 0; i < seg; i++) {
      const a0 = i / seg * Math.PI * 2, a1 = (i + 1) / seg * Math.PI * 2;
      const c0 = Math.cos(a0), s0 = Math.sin(a0), c1 = Math.cos(a1), s1 = Math.sin(a1);
      const n0 = [c0, 0, s0], n1 = [c1, 0, s1];
      V(a, [c0 * 0.5, -0.5, s0 * 0.5], n0); V(a, [c0 * 0.5, 0.5, s0 * 0.5], n0); V(a, [c1 * 0.5, 0.5, s1 * 0.5], n1);
      V(a, [c0 * 0.5, -0.5, s0 * 0.5], n0); V(a, [c1 * 0.5, 0.5, s1 * 0.5], n1); V(a, [c1 * 0.5, -0.5, s1 * 0.5], n1);
      V(a, [0, 0.5, 0], [0, 1, 0]); V(a, [c1 * 0.5, 0.5, s1 * 0.5], [0, 1, 0]); V(a, [c0 * 0.5, 0.5, s0 * 0.5], [0, 1, 0]);
      V(a, [0, -0.5, 0], [0, -1, 0]); V(a, [c0 * 0.5, -0.5, s0 * 0.5], [0, -1, 0]); V(a, [c1 * 0.5, -0.5, s1 * 0.5], [0, -1, 0]);
    }
    return a;
  }
  function octaData() {
    const a = [], X = [[0.5, 0, 0], [-0.5, 0, 0]], Y = [[0, 0.5, 0], [0, -0.5, 0]], Z = [[0, 0, 0.5], [0, 0, -0.5]];
    for (const x of X) for (const y of Y) for (const z of Z) {
      const n = [Math.sign(x[0]), Math.sign(y[1]), Math.sign(z[2])].map(v => v / Math.SQRT2 / Math.SQRT2 * 1.2247);
      V(a, x, n); V(a, y, n); V(a, z, n);
    }
    return a;
  }

  window.TMRLibs.renderer3d = {
    particles: [], floats: [],
    init(r) {
      const cam = r.camera;
      cam.mode = r.player.camera === "third" ? "third" : "first"; cam.distance = r.player.cameraDistance || 4;
      r.on("keydown", k => { if (k === "v") cam.mode = cam.mode === "third" ? "first" : "third"; });
      r.on("collect", e => { this.burst(e.x, e.y, e.z, e.color || "#fbbf24", 14); this.float(e.x, e.y + 0.5, e.z, "+" + (e.value ?? 1), e.color || "#fbbf24"); });
      r.on("hit", () => { const p = r.player; this.burst(p.x, p.y + 1, p.z, "#f87171", 20); cam.shake = 0.5; });
      r.on("win", () => { const p = r.player; this.burst(p.x, p.y + 1, p.z, "#34d399", 40); });
      r.on("float", o => this.float(o.x, o.y, o.z ?? 0, o.text, o.color));
      r.on("reset", () => { this.particles.length = 0; this.floats.length = 0; });
    },
    burst(x, y, z, color, n) {
      const c = col(color);
      for (let i = 0; i < n && this.particles.length < 300; i++) {
        const a = Math.random() * Math.PI * 2, s = 1.5 + Math.random() * 3.5;
        this.particles.push({ x, y, z, vx: Math.cos(a) * s, vy: 2 + Math.random() * 4, vz: Math.sin(a) * s, life: 0.8, c });
      }
    },
    float(x, y, z, text, color) { this.floats.push({ x, y, z, text, color: color || "#f8fafc", life: 1 }); },

    setup(r) {
      this.tried = true;
      const gl = r.canvas.getContext("webgl", { antialias: true, alpha: false }) || r.canvas.getContext("experimental-webgl");
      if (!gl) return;
      const sh = (type, src) => { const s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s); if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s)); return s; };
      const prog = gl.createProgram();
      gl.attachShader(prog, sh(gl.VERTEX_SHADER, VS)); gl.attachShader(prog, sh(gl.FRAGMENT_SHADER, FS)); gl.linkProgram(prog);
      if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(prog));
      gl.useProgram(prog);
      const L = this.L = {};
      for (const n of ["a_pos", "a_nrm"]) { L[n] = gl.getAttribLocation(prog, n); gl.enableVertexAttribArray(L[n]); }
      for (const n of ["u_mvp", "u_model", "u_rot", "u_color", "u_sun", "u_fogc", "u_eye", "u_emit", "u_grid", "u_fogd", "u_amb"]) L[n] = gl.getUniformLocation(prog, n);
      const mesh = d => { const buf = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, buf); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(d), gl.STATIC_DRAW); return { buf, n: d.length / 6 }; };
      this.mesh = { cube: mesh(cubeData()), sphere: mesh(sphereData()), cyl: mesh(cylinderData()), octa: mesh(octaData()) };
      gl.enable(gl.DEPTH_TEST);
      this.gl = gl;
    },
    draw(mesh, m, rot, color, emit, grid) {
      const gl = this.gl, L = this.L;
      gl.uniformMatrix4fv(L.u_mvp, false, mul(this.vp, m)); gl.uniformMatrix4fv(L.u_model, false, m);
      gl.uniform2f(L.u_rot, Math.cos(rot || 0), Math.sin(rot || 0));
      gl.uniform3f(L.u_color, color[0], color[1], color[2]); gl.uniform1f(L.u_emit, emit || 0); gl.uniform1f(L.u_grid, grid || 0);
      if (this.cur !== mesh) {
        gl.bindBuffer(gl.ARRAY_BUFFER, mesh.buf);
        gl.vertexAttribPointer(L.a_pos, 3, gl.FLOAT, false, 24, 0); gl.vertexAttribPointer(L.a_nrm, 3, gl.FLOAT, false, 24, 12);
        this.cur = mesh;
      }
      gl.drawArrays(gl.TRIANGLES, 0, mesh.n);
    },
    message(r, text) {
      const c = r.ctx, v = r.view; c.clearRect(0, 0, v.width, v.height);
      c.fillStyle = "#0b1020"; c.fillRect(0, 0, v.width, v.height);
      c.fillStyle = "#f87171"; c.font = "18px system-ui, sans-serif"; c.textAlign = "center"; c.fillText(text, v.width / 2, v.height / 2);
    },

    render(r, alpha) {
      if (!this.tried) { try { this.setup(r); } catch (e) { console.error("[TMR] WebGL:", e); this.err = e.message; } }
      if (!this.gl) return this.message(r, "WebGL недоступен: " + (this.err || "браузер не поддерживает"));
      const gl = this.gl, V = r.view, w = r.world, p = r.player, cam = r.camera, dt = r.dt, sim = r.state !== "paused", cvs = r.canvas;
      const a = r.state === "playing" && p.px !== undefined ? alpha : 1;
      const ix = p.px + (p.x - p.px) * a, iy = p.py + (p.y - p.py) * a, iz = p.pz + (p.z - p.pz) * a;
      if (sim) cam.shake = Math.max(0, cam.shake - dt * 1.5);

      // Камера
      const cp = Math.cos(p.pitch), dir = [-Math.sin(p.yaw) * cp, Math.sin(p.pitch), -Math.cos(p.yaw) * cp], third = cam.mode === "third";
      let eye, target;
      if (!third) { eye = [ix, iy + p.height * 0.92, iz]; target = [eye[0] + dir[0], eye[1] + dir[1], eye[2] + dir[2]]; }
      else { target = [ix, iy + p.height * 0.75, iz]; eye = [target[0] - dir[0] * cam.distance, Math.max(0.25, target[1] - dir[1] * cam.distance), target[2] - dir[2] * cam.distance]; }
      if (sim && cam.shake) { const s = cam.shake * 0.1; eye[0] += (Math.random() - 0.5) * s; eye[1] += (Math.random() - 0.5) * s; target[1] += (Math.random() - 0.5) * s; }
      this.vp = mul(persp((p.fov || 65) * Math.PI / 180, V.width / V.height, 0.1, 300), lookAt(eye, target));

      const sky = col(w.background, [0.62, 0.79, 0.96]);
      gl.viewport(0, 0, cvs.width, cvs.height);
      gl.clearColor(sky[0], sky[1], sky[2], 1); gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
      const L = this.L;
      gl.uniform3f(L.u_sun, 0.45, 1, 0.3); gl.uniform1f(L.u_amb, 0.64);
      gl.uniform3f(L.u_fogc, sky[0], sky[1], sky[2]); gl.uniform3f(L.u_eye, eye[0], eye[1], eye[2]);
      gl.uniform1f(L.u_fogd, w.fog === false ? 0 : (w.fogDensity ?? 0.012));
      this.cur = null;
      const M = this.mesh, t = r.clock;

      if (w.ground !== false) this.draw(M.cube, model(0, -0.1, 0, w.width, 0.2, w.depth), 0, col(w.ground, [0.23, 0.36, 0.23]), 0, 2);

      for (const e of r.entities) {
        if (!e.active) continue;
        const box = e.width > 0 && e.height > 0 && e.depth > 0, rad = e.radius;
        switch (e.type) {
          case "wall": case "box":
            if (box) this.draw(M.cube, model(e.x, e.y, e.z, e.width, e.height, e.depth), 0, col(e.color, e.type === "wall" ? [0.36, 0.42, 0.53] : [0.55, 0.36, 0.96]), e.emit || 0, e.grid ?? 2);
            break;
          case "sphere": {
            const d = (rad || 0.5) * 2; this.draw(M.sphere, model(e.x, e.y, e.z, d, d, d), 0, col(e.color, [0.8, 0.8, 0.9]), e.emit || 0, 0); break;
          }
          case "collectible": {
            const d = (rad || 0.35) * 2, bob = Math.sin(t * 3 + e.id) * 0.12;
            this.draw(M.octa, model(e.x, e.y + bob, e.z, d, d * 1.3, d, t * 1.6), t * 1.6, col(e.color, [0.98, 0.75, 0.14]), 0.45, 0); break;
          }
          case "hazard": {
            const em = 0.2 + 0.15 * Math.sin(t * 6), c = col(e.color, [0.94, 0.27, 0.27]);
            if (box) this.draw(M.cube, model(e.x, e.y, e.z, e.width, e.height, e.depth), 0, c, em, 0);
            else { const d = (rad || 0.5) * 2; this.draw(M.sphere, model(e.x, e.y, e.z, d, d, d), 0, c, em, 0); }
            break;
          }
          case "goal": {
            const locked = e.requires && r.count("collectible") > 0;
            if (box) this.draw(M.cube, model(e.x, e.y, e.z, e.width, e.height, e.depth), 0, locked ? [0.4, 0.45, 0.55] : [0.2, 0.83, 0.6], locked ? 0 : 0.4, 0);
            else { const d = (rad || 1) * 2; this.draw(M.cyl, model(e.x, e.y, e.z, d, e.height || 3, d), 0, locked ? [0.4, 0.45, 0.55] : [0.2, 0.83, 0.6], locked ? 0 : 0.35 + 0.15 * Math.sin(t * 4), 0); }
            break;
          }
        }
      }

      // Игрок виден только в режиме от 3-го лица
      if (third && !(p.invuln > 0 && Math.floor(t * 10) % 2 === 0)) {
        const pc = col(p.color, [0.38, 0.65, 0.98]), hb = p.height * 0.68, d = p.radius * 2;
        this.draw(M.cyl, model(ix, iy + hb / 2, iz, d, hb, d), 0, pc, 0, 0);
        const hd = p.radius * 2.2; this.draw(M.sphere, model(ix, iy + hb + hd * 0.45, iz, hd, hd, hd), 0, [0.88, 0.95, 1], 0.1, 0);
      }

      // Частицы
      if (sim) {
        for (const q of this.particles) { q.life -= dt; q.vy -= 9 * dt; q.x += q.vx * dt; q.y += q.vy * dt; q.z += q.vz * dt; }
        this.particles = this.particles.filter(q => q.life > 0);
        for (const f of this.floats) { f.life -= dt * 0.9; f.y += 0.8 * dt; }
        this.floats = this.floats.filter(f => f.life > 0);
      }
      for (const q of this.particles) { const s = 0.1 + 0.1 * q.life; this.draw(M.cube, model(q.x, q.y, q.z, s, s, s), 0, q.c, 0.8, 0); }

      // Всплывающие тексты — на слое HUD
      const c = r.ctx;
      c.clearRect(0, 0, V.width, V.height);
      c.textAlign = "center"; c.font = "bold 16px system-ui, sans-serif";
      for (const f of this.floats) {
        const vp = this.vp, cx = vp[0] * f.x + vp[4] * f.y + vp[8] * f.z + vp[12], cy = vp[1] * f.x + vp[5] * f.y + vp[9] * f.z + vp[13], cw = vp[3] * f.x + vp[7] * f.y + vp[11] * f.z + vp[15];
        if (cw <= 0.1) continue;
        c.globalAlpha = Math.max(0, Math.min(1, f.life)); c.lineWidth = 3; c.strokeStyle = "rgba(8,12,24,.85)";
        const sx = (cx / cw * 0.5 + 0.5) * V.width, sy = (1 - (cy / cw * 0.5 + 0.5)) * V.height;
        c.strokeText(f.text, sx, sy); c.fillStyle = f.color; c.fillText(f.text, sx, sy);
      }
      c.globalAlpha = 1;
    }
  };
})();
